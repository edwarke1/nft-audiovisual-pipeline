1. Go to github.com
2. Create new repository
3. Upload zip package
4. Commit changes
5. Clone to deploy