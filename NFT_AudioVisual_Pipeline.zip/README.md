# NFT Audio-Visual Pipeline
Setup and run scripts as described.